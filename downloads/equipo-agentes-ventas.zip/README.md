# Equipo de agentes de ventas

8 subagentes permanentes para Claude Code, listos para instalar en cualquier
proyecto. Cubren el flujo comercial completo: prospección → calificación →
outreach → objeciones → propuesta → seguimiento → coaching de llamadas →
revisión de tono.

## Instalación

1. Descomprimí este ZIP.
2. Copiá la carpeta `.claude/agents/` dentro de tu proyecto (o mergeala si ya
   tenés una carpeta `.claude/agents/` con otros agentes):
   ```
   cp -r .claude/agents/* /ruta/a/tu-proyecto/.claude/agents/
   ```
3. Si Claude Code ya está abierto en ese proyecto, reiniciá la sesión — los
   agentes se cargan al arrancar, no en caliente.
4. Confirmá que los 8 quedaron cargados con `/agents`.

## Los 8 agentes

| Agente | Rol | Herramientas |
|---|---|---|
| `investigador-prospecto` | Research de la empresa/contacto antes de la llamada | WebSearch, WebFetch |
| `calificador-leads` | Califica un lead contra el ICP | Read |
| `redactor-frio` | Escribe el mensaje de prospección en frío | Read |
| `manejador-objeciones` | Da la respuesta a una objeción puntual | Read |
| `redactor-propuesta` | Arma el borrador de la propuesta de una página | Read |
| `redactor-seguimiento` | Escribe la secuencia de seguimiento (día 3/7/14) | Read |
| `coach-llamadas` | Feedback de coaching sobre una transcripción | Read |
| `revisor-tono` | Revisa (no reescribe) el tono de cualquier copy | Read |

## Prompts de orquestación

### Prospección → primer contacto (en paralelo cuando son varios prospectos)
```
Usá investigador-prospecto para investigar [lista de empresas/contactos] en
paralelo (lanzalos todos a la vez). Con cada research, pasale el resultado a
redactor-frio para que escriba el mensaje de outreach. Pasame los mensajes
listos para revisar antes de enviar.
```

### Después de una llamada (en secuencia)
```
Tengo la transcripción de la llamada con [prospecto] en [archivo/pegado
abajo]. Usá coach-llamadas para darme feedback de la llamada, y en paralelo
usá redactor-propuesta para armar el borrador de la propuesta con esas
notas. Cuando esté el borrador, pasaselo a revisor-tono antes de mostrármelo.
```

### Objeción en vivo o por escrito
```
El prospecto respondió esto: "[objeción exacta]". Usá manejador-objeciones
para darme la respuesta.
```

### Seguimiento a un prospecto frío
```
Este prospecto no respondió desde [fecha]. Acá está el historial:
[pegar]. Usá redactor-seguimiento para armarme la secuencia de 3 mensajes.
```

## Notas

- Todos los agentes están en español, tono directo — ajustá el `prompt` de
  cada `.md` si tu equipo usa otro tono o si vendés en otro idioma.
- `investigador-prospecto` es el único con acceso a internet (WebSearch,
  WebFetch). El resto solo lee lo que vos le pasás — no inventan datos de
  fuentes externas.
- Ninguno tiene `Write` ni `Edit`: son agentes de análisis y redacción, no
  tocan archivos del repo. Si querés que `redactor-propuesta` guarde el
  borrador directo en un archivo, agregale `Write` al campo `tools` de su
  `.md` — es la misma reja que viste en la lección del auditor de tokens.
