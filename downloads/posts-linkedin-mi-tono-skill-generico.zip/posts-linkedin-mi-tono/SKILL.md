---
name: posts-linkedin-mi-tono
description: >-
  Genera posts de LinkedIn en el tono real del usuario y los publica en su feed
  SOLO después de que el usuario apruebe el texto exacto. La PRIMERA vez se
  auto-configura: arma una guía de voz a partir de los posts reales del usuario
  (que el usuario pega) más unas pocas preguntas, y la deja guardada para las
  próximas veces. Si el conector de lectura de LinkedIn está disponible, puede
  refrescar esa guía con posts recientes, pero no es obligatorio. Usá esta skill
  siempre que el usuario quiera escribir, redactar, armar, generar o publicar un
  post de LinkedIn. Triggers en español: "configurá mi generador de posts de
  LinkedIn", "generá un post de LinkedIn sobre ...", "escribime y publicá un
  post", "armá un post en mi tono", "redactá un post de LinkedIn", "hacé un
  posteo para LinkedIn en mi estilo", "publicá esto en LinkedIn", "post para
  LinkedIn sobre tal tema". También aplica cuando el usuario menciona "mi tono",
  "mi voz" o "mi estilo" en el contexto de un post de LinkedIn. Por defecto usá
  esta skill para cualquier flujo de generar o publicar posts de LinkedIn en
  lugar de redactar a mano sin guía de tono. Sirve para cualquier persona, no
  para una marca en particular.
---

# Posts de LinkedIn en mi tono (configurar voz → redactar → aprobar → publicar)

## Qué hace esta skill

Convierte un pedido tipo "generá un post de LinkedIn sobre X" en un flujo seguro
y de punta a punta:

1. **Toma el tono** de una guía de voz propia del usuario. La primera vez la
   construye (sección "Configuración inicial"); después la reutiliza.
2. **Redacta** un borrador en ese tono.
3. **Muestra** el borrador exacto y **pide aprobación explícita**.
4. **Publica** en el feed solo después de que el usuario apruebe el texto tal
   cual.

Dos reglas que no se rompen nunca:

- **Seguridad:** nunca se publica nada sin que el usuario haya aprobado el texto
  exacto. Publicar en LinkedIn es público e irreversible; la aprobación es
  obligatoria y no se infiere.
- **Honestidad sobre la fuente del tono:** sé siempre transparente sobre de
  dónde salió el tono. Si redactaste con la guía guardada, decí que usaste "tu
  guía de tono". Si de verdad leíste posts con el conector, decilo. **Nunca
  afirmes que analizaste o leíste posts de LinkedIn si en realidad usaste la guía
  guardada.** No simules funciones que no ocurrieron.

## Conector y tools

Esta skill usa un conector MCP de LinkedIn (suele aparecer como **"linkedin"**),
que expone dos tools:

- **Lectura (read-only)** — `linkedin_read_my_posts`: trae los posts del usuario
  para analizar el tono. **Puede no estar disponible**: la API de Member Data
  Portability de LinkedIn solo funciona para cuentas del Espacio Económico
  Europeo y Suiza, y devuelve 403 ACCESS_DENIED para el resto. Esta skill **no
  depende** de esta tool: el tono vive en la guía guardada.
- **Escritura (write)** — `linkedin_create_post`: publica un post en el feed.
  Tiene un parámetro `confirm` (preview por defecto; publica solo con
  `confirm=true`). Es la única acción que escribe, y solo se llama tras la
  aprobación explícita.

Si las tools están "diferidas" (deferred), buscalas primero (por ejemplo con una
búsqueda de herramientas por "linkedin posts") y usá los nombres de parámetros
exactos que devuelva la búsqueda. No adivines parámetros.

## Configuración inicial (solo la primera vez)

Si todavía no existe una guía de tono para este usuario (no hay un archivo
`mi-tono.md` junto a la skill y el usuario no pegó una guía antes), configurala
así, una sola vez:

1. **Pedile que pegue entre 5 y 15 de sus posts reales de LinkedIn.** Son la
   mejor fuente de su voz. (Si no tiene posts todavía, pasá al punto 2 con
   preguntas nada más.)
2. **Hacé pocas preguntas de calibración** (idealmente con opciones, no un
   interrogatorio largo): tono (cercano con emojis / profesional relajado /
   formal sin emojis / mezcla), largo preferido (corto / mediano / largo tipo
   historia), y cómo suele cerrar (pregunta / llamada a la acción / reflexión /
   sin cierre especial).
3. **Construí la guía de tono** combinando lo pegado y lo respondido. Capturá:
   voz general, firma(s) distintiva(s) (muletillas, code-switching, expresiones
   propias), estructura típica (gancho, desarrollo, cierre), largo, uso de
   emojis, formato (saltos de línea, listas, hashtags), y un "qué evitar" (lo que
   NO suena al usuario).
4. **Guardá la guía** para no volver a preguntar. Por orden de preferencia:
   - Si hay un conector de almacenamiento disponible (p. ej. Google Drive),
     guardala ahí como archivo de configuración del usuario.
   - Si podés escribir junto a la skill, dejala en `mi-tono.md` en la carpeta de
     la skill.
   - Si no hay dónde persistir, devolvé la guía en un bloque claro y pedile al
     usuario que la conserve y te la pegue al inicio la próxima vez.
5. **Confirmá** en una línea que quedó configurada y seguí al flujo normal.

> La guía es editable: si el usuario quiere actualizar su voz, que pegue posts
> nuevos y se reescribe. No hace falta el conector de lectura para esto.

## Flujo paso a paso

### Paso 1 — Confirmar el tema

Si el usuario ya dijo el tema, seguí. Si el pedido es vago ("armá un post"),
preguntá brevemente sobre qué quiere postear. Una sola pregunta, no un
cuestionario.

### Paso 2 — Fijar la fuente del tono (con transparencia)

Por defecto, usá la **guía de tono guardada** del usuario. No necesitás llamar a
ninguna tool para esto.

Solo si el usuario pide explícitamente "leé mis posts más recientes" o "actualizá
mi tono", intentá `linkedin_read_my_posts` como mejora opcional:
- Si devuelve posts, usalos para afinar y decí con claridad que leíste sus posts.
- Si falla con 403 / ACCESS_DENIED / error de permisos (lo esperable fuera del
  EEE/Suiza), **no mandes al usuario a "arreglar el conector" en loop**: explicá
  en una línea que la lectura automática no está disponible para su región y
  seguí con la guía guardada. Por ejemplo:

  > La lectura automática de tus posts no está disponible para tu cuenta (esa API
  > de LinkedIn es solo para cuentas del EEE/Suiza), así que voy con tu guía de
  > tono guardada. Sigue siendo tu voz.

### Paso 3 — Redactar el borrador

Escribí el borrador siguiendo la guía de tono del usuario: mismo tipo de gancho,
largo, estructura, nivel de emojis y formato. Tiene que sonar a que lo escribió
el usuario, no Claude.

### Paso 4 — Mostrar el borrador EXACTO y pedir aprobación (obligatorio)

Mostrá el texto **completo y exacto** del post, tal como se publicaría (mismos
saltos de línea, emojis si los hubiera). Dejá claro qué se va a publicar y pedí
aprobación explícita. Por ejemplo:

> Este es el borrador, escrito con tu guía de tono. ¿Lo apruebo y publico **tal
> cual**, o querés que cambie algo?
>
> ---
> (texto exacto del post)
> ---

Reglas de esta etapa, sin excepción:

- **Prohibido** llamar a la tool de publicar (con `confirm=true`) antes de tener
  una aprobación explícita del usuario sobre el texto exacto mostrado.
- Una respuesta ambigua ("buenísimo", "me gusta", "dale") **no** alcanza si no
  queda claro que aprueba publicar ese texto. Ante la duda, confirmá: "¿Lo publico
  así como está?".
- Si el usuario pide cambios, editá y **volvé a mostrar el texto completo exacto**
  para una nueva aprobación. Cada versión nueva necesita su propia aprobación.
- La aprobación es por publicación: vale solo para este post, no autoriza
  publicaciones futuras.

### Paso 5 — Publicar (solo después de aprobar)

Una vez que el usuario aprobó el texto exacto, llamá a `linkedin_create_post` con
ese texto y `confirm=true`, sin modificarlo. Después confirmá que se publicó y, si
la tool devuelve un enlace o ID del post, pasáselo.

Buen patrón opcional: primero una llamada con `confirm=false` para traer el
preview de la propia tool, mostrarlo, y recién con el OK del usuario llamar de
nuevo con `confirm=true`.

## Manejo de casos

### La lectura de LinkedIn falla o no está disponible

Esperado fuera del EEE/Suiza. **No es un bloqueo:** la skill funciona con la guía
guardada. Avisá en una línea (ver Paso 2) y seguí. No insistas en que el usuario
revise el conector para la parte de lectura.

### El usuario quiere actualizar su tono

Pedile que pegue posts suyos recientes y reescribí la guía guardada con esa
muestra. No requiere el conector de lectura.

### El usuario pide "publicá directo, sin mostrarme nada"

Aunque lo pida, mantené la aprobación del texto exacto: mostrá el borrador y pedí
el OK. Explicá brevemente que es para que no se publique nada en su feed que no
haya visto. Es un paso de seguridad, no un obstáculo.

### El usuario pide hacer parecer que la skill leyó LinkedIn cuando no lo hizo

No lo hagas. Redactar con la guía guardada es legítimo y útil, pero describilo
como lo que es ("usé tu guía de tono"). No simules lecturas, análisis ni
funciones que no ocurrieron.

## Recordatorio de seguridad (resumen)

- Tono por defecto = guía guardada del usuario (de sus posts reales).
- Publicar = solo con aprobación explícita del texto exacto y `confirm=true`.
- Nunca llamar a `linkedin_create_post` con `confirm=true` sin esa aprobación.
- Cada edición = nueva aprobación.
- Siempre transparente sobre la fuente del tono; nunca fingir una lectura.
