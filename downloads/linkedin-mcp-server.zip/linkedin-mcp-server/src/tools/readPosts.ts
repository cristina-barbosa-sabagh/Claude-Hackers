/**
 * Tool: linkedin_read_my_posts
 *
 * Reads the member's own posts via the Member Data Portability Changelog API,
 * accumulating them in a local cache so history grows beyond the 28-day window.
 * Read-only with respect to LinkedIn (it only triggers changelog generation,
 * which is the documented, non-destructive enablement call).
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import {
  ReadMyPostsInputSchema,
  ResponseFormat,
  type ReadMyPostsInput,
} from "../schemas/index.js";
import type { AppConfig } from "../config.js";
import { CHARACTER_LIMIT } from "../constants.js";
import { listCachedPosts, loadCache, syncPosts } from "../services/cache.js";
import { ReauthRequiredError } from "../services/tokens.js";
import { LinkedInApiError } from "../services/linkedin.js";
import type { CachedPost } from "../types.js";

function toIso(epochMs: number): string {
  return new Date(epochMs).toISOString();
}

interface ReadOutput {
  total: number;
  count: number;
  offset: number;
  synced: boolean;
  new_posts_synced?: number;
  last_synced_at?: string;
  posts: Array<{
    resource_id: string;
    text: string;
    captured_at: string;
    resource_name: string;
  }>;
  has_more: boolean;
  next_offset?: number;
  notice?: string;
}

export function registerReadMyPosts(server: McpServer, config: AppConfig): void {
  server.registerTool(
    "linkedin_read_my_posts",
    {
      title: "Read My LinkedIn Posts",
      description: `Read YOUR OWN LinkedIn posts so they can be analyzed (e.g. to study your writing tone and style).

This tool uses LinkedIn's official Member Data Portability "Member Changelog" API (scope r_dma_portability_member). It does NOT scrape and does not read anyone else's data. Because the Changelog API only retains the last 28 days of events, this tool keeps a local cache and accumulates your posts over time, so repeated runs build a longer history.

Args:
  - sync (boolean): Pull new events from LinkedIn before returning (default: true). Set false for a cache-only, offline read.
  - limit (number): Max posts to return, 1-100 (default: 20).
  - offset (number): Posts to skip from newest, for pagination (default: 0).
  - since (string, optional): ISO-8601 timestamp; only posts captured at/after this time.
  - response_format ('markdown' | 'json'): Output format (default: 'markdown').

Returns (JSON shape):
  {
    "total": number,              // total posts in cache matching the filter
    "count": number,              // posts returned in this response
    "offset": number,
    "synced": boolean,            // whether a sync ran this call
    "new_posts_synced": number,   // new posts added by this sync (if synced)
    "last_synced_at": string,     // ISO timestamp of last successful sync
    "posts": [
      { "resource_id": string, "text": string, "captured_at": string, "resource_name": string }
    ],
    "has_more": boolean,
    "next_offset": number         // present when has_more is true
  }

Examples:
  - "Analyze the tone of my last 10 LinkedIn posts" -> { limit: 10 }
  - "Quick offline look at what's cached" -> { sync: false }

Notes & errors:
  - First run may return few or zero posts: LinkedIn only archives activity that happens AFTER you consent, so history fills in over time as you post (or as you run periodic syncs).
  - Member Data Portability is currently available only to LinkedIn members in the European Economic Area and Switzerland.
  - If your token expired, you'll get a clear message to run \`npm run auth\` again.`,
      inputSchema: ReadMyPostsInputSchema.shape,
      annotations: {
        readOnlyHint: true,
        destructiveHint: false,
        idempotentHint: true,
        openWorldHint: true,
      },
    },
    async (params: ReadMyPostsInput) => {
      try {
        let newPostsSynced: number | undefined;
        if (params.sync) {
          const result = await syncPosts(config);
          newPostsSynced = result.newPosts;
        }

        const cache = await loadCache(config);
        let posts: CachedPost[] = listCachedPosts(cache);

        if (params.since) {
          const sinceMs = Date.parse(params.since);
          posts = posts.filter((p) => p.capturedAt >= sinceMs);
        }

        const total = posts.length;
        const page = posts.slice(params.offset, params.offset + params.limit);
        const hasMore = total > params.offset + page.length;

        const output: ReadOutput = {
          total,
          count: page.length,
          offset: params.offset,
          synced: params.sync,
          ...(newPostsSynced !== undefined
            ? { new_posts_synced: newPostsSynced }
            : {}),
          ...(cache.lastSyncedAt ? { last_synced_at: cache.lastSyncedAt } : {}),
          posts: page.map((p) => ({
            resource_id: p.resourceId,
            text: p.text,
            captured_at: toIso(p.capturedAt),
            resource_name: p.resourceName,
          })),
          has_more: hasMore,
          ...(hasMore ? { next_offset: params.offset + page.length } : {}),
        };

        if (total === 0) {
          output.notice =
            "No posts are cached yet. LinkedIn only archives activity created after you consented, so post something (or run sync again later) and your history will accumulate. Member Data Portability is also limited to EEA/Switzerland members.";
        }

        let text: string;
        if (params.response_format === ResponseFormat.JSON) {
          text = JSON.stringify(output, null, 2);
        } else {
          text = renderMarkdown(output);
        }

        if (text.length > CHARACTER_LIMIT) {
          const half = Math.max(1, Math.floor(page.length / 2));
          output.posts = output.posts.slice(0, half);
          output.notice =
            `Response truncated to the newest ${half} posts to stay within size limits. ` +
            `Use 'offset' to page through the rest.`;
          text =
            params.response_format === ResponseFormat.JSON
              ? JSON.stringify(output, null, 2)
              : renderMarkdown(output);
        }

        return {
          content: [{ type: "text", text }],
          structuredContent: output as unknown as Record<string, unknown>,
        };
      } catch (err) {
        return { content: [{ type: "text", text: formatError(err) }], isError: true };
      }
    }
  );
}

function renderMarkdown(output: ReadOutput): string {
  const lines: string[] = [];
  lines.push(`# My LinkedIn Posts`);
  lines.push("");
  lines.push(
    `Showing ${output.count} of ${output.total} cached post(s)` +
      (output.synced
        ? ` (sync ran${
            output.new_posts_synced !== undefined
              ? `, ${output.new_posts_synced} new`
              : ""
          }).`
        : ` (cache-only, no sync).`)
  );
  if (output.last_synced_at) {
    lines.push(`Last synced: ${output.last_synced_at}`);
  }
  lines.push("");

  if (output.notice) {
    lines.push(`> ${output.notice}`);
    lines.push("");
  }

  for (const post of output.posts) {
    lines.push(`## ${post.captured_at}`);
    lines.push(`- **Resource**: ${post.resource_name} (${post.resource_id})`);
    lines.push("");
    lines.push(post.text);
    lines.push("");
  }

  if (output.has_more) {
    lines.push(
      `_More posts available. Use offset=${output.next_offset} to continue._`
    );
  }
  return lines.join("\n");
}

function formatError(err: unknown): string {
  if (err instanceof ReauthRequiredError) return `Error: ${err.message}`;
  if (err instanceof LinkedInApiError) return `Error: ${err.message}`;
  return `Error: Unexpected failure reading posts: ${
    err instanceof Error ? err.message : String(err)
  }`;
}
