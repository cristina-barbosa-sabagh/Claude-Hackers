/**
 * Tool: linkedin_create_post
 *
 * Publishes a text post to the member's own feed via the Posts API
 * (scope w_member_social, "Share on LinkedIn" product).
 *
 * SAFETY: `confirm` defaults to false. With confirm=false the tool returns a
 * preview and publishes NOTHING. Only confirm=true performs the irreversible
 * publish. The tool is annotated destructive so clients surface extra caution.
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import {
  CreatePostInputSchema,
  PostVisibility,
  ResponseFormat,
  type CreatePostInput,
} from "../schemas/index.js";
import type { AppConfig } from "../config.js";
import {
  createTextPost,
  resolveAuthorUrn,
  LinkedInApiError,
} from "../services/linkedin.js";
import { ReauthRequiredError } from "../services/tokens.js";

interface PreviewOutput {
  status: "preview";
  published: false;
  author_urn: string;
  visibility: PostVisibility;
  character_count: number;
  text: string;
  message: string;
}

interface PublishedOutput {
  status: "published";
  published: true;
  author_urn: string;
  visibility: PostVisibility;
  post_urn: string | null;
  text: string;
  message: string;
}

export function registerCreatePost(server: McpServer, config: AppConfig): void {
  server.registerTool(
    "linkedin_create_post",
    {
      title: "Create LinkedIn Post",
      description: `Publish a text post to YOUR OWN LinkedIn feed using the official Posts API (scope w_member_social, the "Share on LinkedIn" product).

SAFETY GATE — read carefully:
  - This tool has a 'confirm' parameter that defaults to FALSE.
  - With confirm=false it ONLY returns a preview and publishes nothing.
  - It publishes to LinkedIn ONLY when called with confirm=true.
  - Correct usage: first call with confirm=false (or omitted), show the returned preview to the user, get their explicit approval, and only then call again with confirm=true. Never set confirm=true on your own initiative.

Args:
  - text (string): Post body, 1-3000 characters.
  - visibility ('PUBLIC' | 'CONNECTIONS'): Audience (default: 'PUBLIC').
  - confirm (boolean): Must be true to actually publish (default: false = preview only).
  - response_format ('markdown' | 'json'): Output format (default: 'markdown').

Returns when confirm=false (preview):
  { "status": "preview", "published": false, "author_urn": string, "visibility": string, "character_count": number, "text": string, "message": string }

Returns when confirm=true (published):
  { "status": "published", "published": true, "author_urn": string, "visibility": string, "post_urn": string|null, "text": string, "message": string }

Notes & errors:
  - Publishing is effectively irreversible from here (you'd have to delete it in the LinkedIn app), which is why explicit confirmation is required.
  - Requires the "Share on LinkedIn" product on your app. A 403 means the scope/product is missing; a 401 means you should run \`npm run auth\` again.`,
      inputSchema: CreatePostInputSchema.shape,
      annotations: {
        readOnlyHint: false,
        destructiveHint: true,
        idempotentHint: false,
        openWorldHint: true,
      },
    },
    async (params: CreatePostInput) => {
      try {
        // Preview must never fail due to network/auth: it publishes nothing.
        if (!params.confirm) {
          let authorUrn = "(will be resolved at publish time)";
          try {
            authorUrn = await resolveAuthorUrn(config);
          } catch {
            // Keep the placeholder; the preview still shows the text safely.
          }
          const output: PreviewOutput = {
            status: "preview",
            published: false,
            author_urn: authorUrn,
            visibility: params.visibility,
            character_count: params.text.length,
            text: params.text,
            message:
              "PREVIEW ONLY — nothing was published. Review the text above with the user. " +
              "To publish, call linkedin_create_post again with the same text and confirm=true.",
          };
          return {
            content: [
              {
                type: "text",
                text:
                  params.response_format === ResponseFormat.JSON
                    ? JSON.stringify(output, null, 2)
                    : renderPreview(output),
              },
            ],
            structuredContent: output as unknown as Record<string, unknown>,
          };
        }

        const authorUrn = await resolveAuthorUrn(config);
        const { postUrn } = await createTextPost(
          config,
          authorUrn,
          params.text,
          params.visibility
        );

        const output: PublishedOutput = {
          status: "published",
          published: true,
          author_urn: authorUrn,
          visibility: params.visibility,
          post_urn: postUrn,
          text: params.text,
          message: postUrn
            ? `Published successfully. Post URN: ${postUrn}`
            : "Published successfully (LinkedIn did not return a post URN header).",
        };
        return {
          content: [
            {
              type: "text",
              text:
                params.response_format === ResponseFormat.JSON
                  ? JSON.stringify(output, null, 2)
                  : renderPublished(output),
            },
          ],
          structuredContent: output as unknown as Record<string, unknown>,
        };
      } catch (err) {
        return {
          content: [{ type: "text", text: formatError(err) }],
          isError: true,
        };
      }
    }
  );
}

function renderPreview(o: PreviewOutput): string {
  return [
    `# LinkedIn Post Preview (NOT published)`,
    "",
    `- **Author**: ${o.author_urn}`,
    `- **Visibility**: ${o.visibility}`,
    `- **Length**: ${o.character_count} characters`,
    "",
    `---`,
    o.text,
    `---`,
    "",
    `> ${o.message}`,
  ].join("\n");
}

function renderPublished(o: PublishedOutput): string {
  return [
    `# LinkedIn Post Published`,
    "",
    `- **Author**: ${o.author_urn}`,
    `- **Visibility**: ${o.visibility}`,
    `- **Post URN**: ${o.post_urn ?? "(not returned)"}`,
    "",
    `---`,
    o.text,
    `---`,
    "",
    `> ${o.message}`,
  ].join("\n");
}

function formatError(err: unknown): string {
  if (err instanceof ReauthRequiredError) return `Error: ${err.message}`;
  if (err instanceof LinkedInApiError) return `Error: ${err.message}`;
  return `Error: Unexpected failure creating post: ${
    err instanceof Error ? err.message : String(err)
  }`;
}
