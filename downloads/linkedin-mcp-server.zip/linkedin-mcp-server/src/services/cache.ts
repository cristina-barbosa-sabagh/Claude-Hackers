/**
 * Local post cache.
 *
 * The Changelog API only retains 28 days of events, so we accumulate the
 * member's own posts into a local JSON file over time. Each sync pulls new
 * events (using the last processedAt as the incremental cursor), extracts
 * post text, and merges them in, deduplicated by resourceId.
 */
import fs from "node:fs/promises";
import path from "node:path";
import {
  CHANGELOG_MAX_COUNT,
  POST_RESOURCE_NAMES,
} from "../constants.js";
import type { AppConfig } from "../config.js";
import { ensureDataDir } from "./tokens.js";
import {
  ensureChangelogEnabled,
  fetchChangelogPage,
} from "./linkedin.js";
import type {
  CachedPost,
  ChangelogEvent,
  PostCacheFile,
} from "../types.js";

const CACHE_FILENAME = "posts-cache.json";

function cachePath(config: AppConfig): string {
  return path.join(config.dataDir, CACHE_FILENAME);
}

const EMPTY_CACHE: PostCacheFile = { lastProcessedAt: 0, posts: {} };

export async function loadCache(config: AppConfig): Promise<PostCacheFile> {
  try {
    const raw = await fs.readFile(cachePath(config), "utf8");
    const parsed = JSON.parse(raw) as PostCacheFile;
    return {
      lastProcessedAt: parsed.lastProcessedAt ?? 0,
      posts: parsed.posts ?? {},
      lastSyncedAt: parsed.lastSyncedAt,
    };
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") {
      return { ...EMPTY_CACHE, posts: {} };
    }
    throw err;
  }
}

export async function saveCache(
  config: AppConfig,
  cache: PostCacheFile
): Promise<void> {
  await ensureDataDir(config);
  await fs.writeFile(cachePath(config), JSON.stringify(cache, null, 2), {
    mode: 0o600,
  });
}

/** Is this changelog event a member-authored post creation/update? */
function isPostEvent(event: ChangelogEvent): boolean {
  if (!POST_RESOURCE_NAMES.includes(event.resourceName)) return false;
  // We care about content that exists; DELETE events carry no body.
  return event.method === "CREATE" || event.method === "UPDATE";
}

/**
 * Best-effort extraction of post commentary text from a changelog event.
 * Handles both the modern Posts shape (`commentary`) and the legacy UGC shape
 * (`specificContent["com.linkedin.ugc.ShareContent"].shareCommentary.text`).
 */
export function extractPostText(event: ChangelogEvent): string | null {
  const sources = [event.processedActivity, event.activity].filter(
    Boolean
  ) as Record<string, unknown>[];

  for (const source of sources) {
    // Modern Posts API shape.
    const commentary = source["commentary"];
    if (typeof commentary === "string" && commentary.trim()) {
      return commentary;
    }

    // Legacy UGC shape.
    const specificContent = source["specificContent"] as
      | Record<string, unknown>
      | undefined;
    const shareContent = specificContent?.[
      "com.linkedin.ugc.ShareContent"
    ] as Record<string, unknown> | undefined;
    const shareCommentary = shareContent?.["shareCommentary"] as
      | Record<string, unknown>
      | undefined;
    const text = shareCommentary?.["text"];
    if (typeof text === "string" && text.trim()) {
      return text;
    }
  }
  return null;
}

export interface SyncResult {
  newPosts: number;
  totalPosts: number;
  pagesFetched: number;
  reachedEnd: boolean;
}

/**
 * Incrementally sync new changelog events into the cache. Walks pages forward
 * using processedAt as the cursor, stops when a page returns no events or when
 * a safety page cap is reached.
 */
export async function syncPosts(
  config: AppConfig,
  maxPages = 20
): Promise<SyncResult> {
  await ensureChangelogEnabled(config);

  const cache = await loadCache(config);
  let cursor = cache.lastProcessedAt || undefined;
  let pagesFetched = 0;
  let newPosts = 0;
  let reachedEnd = false;

  while (pagesFetched < maxPages) {
    const events = await fetchChangelogPage(
      config,
      cursor,
      CHANGELOG_MAX_COUNT
    );
    pagesFetched += 1;

    if (events.length === 0) {
      reachedEnd = true;
      break;
    }

    let maxProcessedAt = cache.lastProcessedAt;
    for (const event of events) {
      if (event.processedAt > maxProcessedAt) {
        maxProcessedAt = event.processedAt;
      }
      if (!isPostEvent(event)) continue;

      const text = extractPostText(event);
      if (!text) continue;

      const existing = cache.posts[event.resourceId];
      const post: CachedPost = {
        resourceId: event.resourceId,
        resourceName: event.resourceName,
        text,
        capturedAt: event.capturedAt,
        processedAt: event.processedAt,
        author: event.owner ?? event.actor,
      };
      if (!existing) newPosts += 1;
      // Keep the most recent version of an updated post.
      if (!existing || event.processedAt >= existing.processedAt) {
        cache.posts[event.resourceId] = post;
      }
    }

    // Advance the cursor. If it didn't move, we've drained the window.
    if (maxProcessedAt <= (cache.lastProcessedAt || 0)) {
      reachedEnd = true;
      cache.lastProcessedAt = maxProcessedAt;
      break;
    }
    cache.lastProcessedAt = maxProcessedAt;
    cursor = maxProcessedAt;

    // A short page means we've caught up.
    if (events.length < CHANGELOG_MAX_COUNT) {
      reachedEnd = true;
      break;
    }
  }

  cache.lastSyncedAt = new Date().toISOString();
  await saveCache(config, cache);

  return {
    newPosts,
    totalPosts: Object.keys(cache.posts).length,
    pagesFetched,
    reachedEnd,
  };
}

/** Return cached posts sorted newest-first. */
export function listCachedPosts(cache: PostCacheFile): CachedPost[] {
  return Object.values(cache.posts).sort(
    (a, b) => b.capturedAt - a.capturedAt
  );
}
