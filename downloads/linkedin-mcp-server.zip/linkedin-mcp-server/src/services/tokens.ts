/**
 * Token storage and refresh.
 *
 * Tokens are stored locally as JSON with 0600 permissions. LinkedIn issues
 * refresh tokens ONLY to approved partner apps; most apps get a ~60-day access
 * token with no refresh token. We refresh automatically when a refresh token is
 * available, and otherwise surface a clear "re-run npm run auth" error.
 */
import fs from "node:fs/promises";
import path from "node:path";
import {
  LINKEDIN_OAUTH_TOKEN_URL,
  REQUEST_TIMEOUT_MS,
} from "../constants.js";
import type {
  AppConfig,
} from "../config.js";
import type { LinkedInTokenResponse, StoredTokens } from "../types.js";

const TOKENS_FILENAME = "tokens.json";

// Refresh a bit early to avoid edge-of-expiry failures.
const EXPIRY_SKEW_MS = 60_000;

function tokensPath(config: AppConfig): string {
  return path.join(config.dataDir, TOKENS_FILENAME);
}

export async function ensureDataDir(config: AppConfig): Promise<void> {
  await fs.mkdir(config.dataDir, { recursive: true });
}

/** Convert a raw token response into a stored bundle with absolute expiries. */
export function toStoredTokens(
  raw: LinkedInTokenResponse,
  existing?: StoredTokens
): StoredTokens {
  const now = Date.now();
  return {
    access_token: raw.access_token,
    refresh_token: raw.refresh_token ?? existing?.refresh_token,
    expires_at: now + raw.expires_in * 1000,
    refresh_token_expires_at:
      raw.refresh_token_expires_in != null
        ? now + raw.refresh_token_expires_in * 1000
        : existing?.refresh_token_expires_at,
    scope: raw.scope ?? existing?.scope,
    author_urn: existing?.author_urn,
  };
}

export async function saveTokens(
  config: AppConfig,
  tokens: StoredTokens
): Promise<void> {
  await ensureDataDir(config);
  const file = tokensPath(config);
  await fs.writeFile(file, JSON.stringify(tokens, null, 2), { mode: 0o600 });
  // Enforce permissions even if the file already existed.
  await fs.chmod(file, 0o600).catch(() => {});
}

export async function loadTokens(
  config: AppConfig
): Promise<StoredTokens | null> {
  try {
    const raw = await fs.readFile(tokensPath(config), "utf8");
    return JSON.parse(raw) as StoredTokens;
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw err;
  }
}

/** Exchange an authorization code for tokens (used by the auth script). */
export async function exchangeCodeForTokens(
  config: AppConfig,
  code: string
): Promise<LinkedInTokenResponse> {
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code,
    redirect_uri: config.redirectUri,
    client_id: config.clientId,
    client_secret: config.clientSecret,
  });
  return postTokenRequest(body);
}

/** Use a refresh token to obtain a fresh access token. */
export async function refreshAccessToken(
  config: AppConfig,
  refreshToken: string
): Promise<LinkedInTokenResponse> {
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    refresh_token: refreshToken,
    client_id: config.clientId,
    client_secret: config.clientSecret,
  });
  return postTokenRequest(body);
}

async function postTokenRequest(
  body: URLSearchParams
): Promise<LinkedInTokenResponse> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(LINKEDIN_OAUTH_TOKEN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
      signal: controller.signal,
    });
    const text = await res.text();
    if (!res.ok) {
      throw new Error(
        `Token endpoint returned ${res.status}: ${text || "(empty body)"}`
      );
    }
    return JSON.parse(text) as LinkedInTokenResponse;
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Error thrown when we cannot produce a valid access token and the user must
 * re-authenticate. The server turns this into an actionable tool error.
 */
export class ReauthRequiredError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ReauthRequiredError";
  }
}

/**
 * Return a valid access token, refreshing transparently when possible.
 * Throws ReauthRequiredError when no token exists or it cannot be refreshed.
 */
export async function getValidAccessToken(config: AppConfig): Promise<string> {
  const tokens = await loadTokens(config);
  if (!tokens) {
    throw new ReauthRequiredError(
      "No stored LinkedIn tokens were found. Run `npm run auth` to sign in and " +
        "authorize the app before using this server."
    );
  }

  const stillValid = tokens.expires_at - EXPIRY_SKEW_MS > Date.now();
  if (stillValid) return tokens.access_token;

  // Access token expired (or about to). Try to refresh.
  if (!tokens.refresh_token) {
    throw new ReauthRequiredError(
      "Your LinkedIn access token has expired and no refresh token is available " +
        "(LinkedIn only issues refresh tokens to approved partner apps). " +
        "Run `npm run auth` again to obtain a new token."
    );
  }

  const refreshExpired =
    tokens.refresh_token_expires_at != null &&
    tokens.refresh_token_expires_at <= Date.now();
  if (refreshExpired) {
    throw new ReauthRequiredError(
      "Your LinkedIn refresh token has expired. Run `npm run auth` again to " +
        "re-authorize the app."
    );
  }

  try {
    const refreshed = await refreshAccessToken(config, tokens.refresh_token);
    const updated = toStoredTokens(refreshed, tokens);
    await saveTokens(config, updated);
    return updated.access_token;
  } catch (err) {
    throw new ReauthRequiredError(
      `Failed to refresh the LinkedIn access token (${
        err instanceof Error ? err.message : String(err)
      }). Run \`npm run auth\` again to re-authorize.`
    );
  }
}
