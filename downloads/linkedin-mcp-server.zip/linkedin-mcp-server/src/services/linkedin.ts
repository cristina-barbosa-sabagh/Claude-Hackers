/**
 * LinkedIn API client.
 *
 * Centralizes authenticated requests, header construction, author-URN
 * resolution, changelog reads, and post creation. All network access for the
 * tools flows through here so error handling and headers stay consistent.
 */
import {
  LINKEDIN_API_BASE,
  RESTLI_PROTOCOL_VERSION,
  REQUEST_TIMEOUT_MS,
  CHANGELOG_MAX_COUNT,
} from "../constants.js";
import type { AppConfig } from "../config.js";
import {
  getValidAccessToken,
  loadTokens,
  saveTokens,
} from "./tokens.js";
import type { ChangelogEvent } from "../types.js";

/** A friendly error whose message is safe to show the model/user. */
export class LinkedInApiError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = "LinkedInApiError";
    this.status = status;
  }
}

interface RequestOptions {
  method?: "GET" | "POST";
  /** Query params for GET requests. */
  query?: Record<string, string | number | undefined>;
  /** JSON body for POST requests. */
  body?: unknown;
  /** Extra headers (merged over defaults). */
  headers?: Record<string, string>;
}

function buildUrl(
  pathname: string,
  query?: Record<string, string | number | undefined>
): string {
  const url = new URL(pathname, LINKEDIN_API_BASE);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined && value !== null) {
        url.searchParams.set(key, String(value));
      }
    }
  }
  return url.toString();
}

/** Make an authenticated request and return parsed JSON plus key headers. */
export async function linkedInRequest<T = unknown>(
  config: AppConfig,
  pathname: string,
  options: RequestOptions = {}
): Promise<{ data: T; headers: Headers; status: number }> {
  const accessToken = await getValidAccessToken(config);
  const url = buildUrl(pathname, options.query);

  const headers: Record<string, string> = {
    Authorization: `Bearer ${accessToken}`,
    "X-Restli-Protocol-Version": RESTLI_PROTOCOL_VERSION,
    "LinkedIn-Version": config.linkedinVersion,
    ...options.headers,
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const init: RequestInit = {
      method: options.method ?? "GET",
      headers,
      signal: controller.signal,
    };
    if (options.body !== undefined) {
      headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(options.body);
    }

    const res = await fetch(url, init);
    const text = await res.text();

    if (!res.ok) {
      throw new LinkedInApiError(describeHttpError(res.status, text), res.status);
    }

    let data: T;
    try {
      data = (text ? JSON.parse(text) : {}) as T;
    } catch {
      data = {} as T;
    }
    return { data, headers: res.headers, status: res.status };
  } catch (err) {
    if (err instanceof LinkedInApiError) throw err;
    if ((err as Error).name === "AbortError") {
      throw new LinkedInApiError(
        "Request to LinkedIn timed out. Please try again."
      );
    }
    throw new LinkedInApiError(
      `Network error contacting LinkedIn: ${
        err instanceof Error ? err.message : String(err)
      }`
    );
  } finally {
    clearTimeout(timeout);
  }
}

/** Turn an HTTP status + body into an actionable message. */
function describeHttpError(status: number, body: string): string {
  const snippet = body ? ` Details: ${body.slice(0, 500)}` : "";
  switch (status) {
    case 400:
      return `LinkedIn rejected the request (400 Bad Request). This usually means a malformed payload or an unsupported LinkedIn-Version.${snippet}`;
    case 401:
      return `LinkedIn returned 401 Unauthorized. Your token may be invalid or expired; run \`npm run auth\` again.${snippet}`;
    case 403:
      return `LinkedIn returned 403 Forbidden. Your app is likely missing the required product/scope for this call (e.g. "Share on LinkedIn" for posting or "Member Data Portability (Member)" for reading).${snippet}`;
    case 404:
      return `LinkedIn returned 404 Not Found. The endpoint or resource path may be wrong for the configured LinkedIn-Version.${snippet}`;
    case 422:
      return `LinkedIn returned 422 Unprocessable Entity. The post content may violate a constraint (e.g. empty text).${snippet}`;
    case 429:
      return `LinkedIn returned 429 Too Many Requests (rate limited). Wait and retry; the Changelog API is meant to be polled at most once per hour.${snippet}`;
    default:
      if (status >= 500) {
        return `LinkedIn had a server error (${status}). Try again shortly.${snippet}`;
      }
      return `LinkedIn request failed with status ${status}.${snippet}`;
  }
}

interface UserInfoResponse {
  sub?: string;
  name?: string;
}

interface MemberAuthorizationsResponse {
  elements?: Array<{
    memberComplianceAuthorizationKey?: { member?: string };
  }>;
}

/**
 * Resolve the current member's person URN, with fallbacks, and cache it
 * alongside the tokens so we only pay the lookup once.
 *
 * Order:
 *   1. Explicit override from .env (LINKEDIN_AUTHOR_URN)
 *   2. Cached value from a previous resolution
 *   3. /v2/userinfo (requires openid+profile scopes)
 *   4. memberAuthorizations finder (requires the DMA member scope)
 */
export async function resolveAuthorUrn(config: AppConfig): Promise<string> {
  if (config.authorUrnOverride) return config.authorUrnOverride;

  const tokens = await loadTokens(config);
  if (tokens?.author_urn) return tokens.author_urn;

  let resolved: string | undefined;

  // Try OpenID userinfo first.
  try {
    const { data } = await linkedInRequest<UserInfoResponse>(
      config,
      "/v2/userinfo"
    );
    if (data.sub) resolved = `urn:li:person:${data.sub}`;
  } catch {
    // ignore and fall through
  }

  // Fall back to the DMA memberAuthorizations finder.
  if (!resolved) {
    try {
      const { data } = await linkedInRequest<MemberAuthorizationsResponse>(
        config,
        "/rest/memberAuthorizations",
        { query: { q: "memberAndApplication" } }
      );
      const member = data.elements?.[0]?.memberComplianceAuthorizationKey?.member;
      if (member) resolved = member;
    } catch {
      // ignore
    }
  }

  if (!resolved) {
    throw new LinkedInApiError(
      "Could not determine your LinkedIn person URN. Enable the " +
        '"Sign In with LinkedIn using OpenID Connect" product (for openid+profile) ' +
        "or set LINKEDIN_AUTHOR_URN in your .env to your own urn:li:person:... value."
    );
  }

  // Cache it for next time.
  if (tokens) {
    await saveTokens(config, { ...tokens, author_urn: resolved });
  }
  return resolved;
}

/**
 * Ensure changelog event generation is enabled for this member. Safe to call
 * repeatedly; LinkedIn enables generation automatically after consent, and this
 * POST is the documented manual trigger. Failures here are non-fatal.
 */
export async function ensureChangelogEnabled(config: AppConfig): Promise<void> {
  try {
    await linkedInRequest(config, "/rest/memberAuthorizations", {
      method: "POST",
      body: {},
    });
  } catch {
    // Non-fatal: generation is usually already enabled after consent.
  }
}

interface ChangelogPage {
  elements?: ChangelogEvent[];
  paging?: { start?: number; count?: number; total?: number };
}

/**
 * Fetch one page of changelog events at or after `startTime` (epoch ms).
 * Returns the raw events; callers handle filtering and persistence.
 */
export async function fetchChangelogPage(
  config: AppConfig,
  startTime: number | undefined,
  count: number = CHANGELOG_MAX_COUNT
): Promise<ChangelogEvent[]> {
  const { data } = await linkedInRequest<ChangelogPage>(
    config,
    "/rest/memberChangeLogs",
    {
      query: {
        q: "memberAndApplication",
        count,
        startTime,
      },
    }
  );
  return data.elements ?? [];
}

/**
 * Create a post (text-only commentary) on the member's feed via the Posts API.
 * Returns the new post URN (read from the response header when present).
 */
export async function createTextPost(
  config: AppConfig,
  authorUrn: string,
  commentary: string,
  visibility: "PUBLIC" | "CONNECTIONS"
): Promise<{ postUrn: string | null }> {
  const body = {
    author: authorUrn,
    commentary,
    visibility,
    distribution: {
      feedDistribution: "MAIN_FEED",
      targetEntities: [],
      thirdPartyDistributionChannels: [],
    },
    lifecycleState: "PUBLISHED",
    isReshareDisabledByAuthor: false,
  };

  const { headers } = await linkedInRequest(config, "/rest/posts", {
    method: "POST",
    body,
  });

  const postUrn =
    headers.get("x-restli-id") ?? headers.get("x-linkedin-id") ?? null;
  return { postUrn };
}
