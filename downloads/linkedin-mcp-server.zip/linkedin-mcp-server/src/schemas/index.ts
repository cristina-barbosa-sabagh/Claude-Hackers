/**
 * Zod input schemas for the LinkedIn MCP tools.
 */
import { z } from "zod";

export enum ResponseFormat {
  MARKDOWN = "markdown",
  JSON = "json",
}

export enum PostVisibility {
  PUBLIC = "PUBLIC",
  CONNECTIONS = "CONNECTIONS",
}

export const ReadMyPostsInputSchema = z
  .object({
    sync: z
      .boolean()
      .default(true)
      .describe(
        "When true (default), pull new events from the LinkedIn Changelog API into the local cache before returning. Set false to read only what is already cached (no network call)."
      ),
    limit: z
      .number()
      .int()
      .min(1)
      .max(100)
      .default(20)
      .describe("Maximum number of posts to return (1-100). Default 20."),
    offset: z
      .number()
      .int()
      .min(0)
      .default(0)
      .describe("Number of posts to skip from the newest, for pagination."),
    since: z
      .string()
      .datetime()
      .optional()
      .describe(
        "Optional ISO-8601 timestamp; only return posts captured at or after this time."
      ),
    response_format: z
      .nativeEnum(ResponseFormat)
      .default(ResponseFormat.MARKDOWN)
      .describe(
        "Output format: 'markdown' for human-readable or 'json' for machine-readable."
      ),
  })
  .strict();

export type ReadMyPostsInput = z.infer<typeof ReadMyPostsInputSchema>;

export const CreatePostInputSchema = z
  .object({
    text: z
      .string()
      .min(1, "Post text cannot be empty.")
      .max(3000, "LinkedIn post text must be at most 3000 characters.")
      .describe("The post body text (commentary). 1-3000 characters."),
    visibility: z
      .nativeEnum(PostVisibility)
      .default(PostVisibility.PUBLIC)
      .describe(
        "Audience: 'PUBLIC' (anyone) or 'CONNECTIONS' (your connections only). Default PUBLIC."
      ),
    confirm: z
      .boolean()
      .default(false)
      .describe(
        "Safety gate. When false (default) the tool returns a PREVIEW and does NOT publish. Only when true does it actually publish to LinkedIn. Always show the preview to the user and get explicit approval before calling again with confirm=true."
      ),
    response_format: z
      .nativeEnum(ResponseFormat)
      .default(ResponseFormat.MARKDOWN)
      .describe(
        "Output format: 'markdown' for human-readable or 'json' for machine-readable."
      ),
  })
  .strict();

export type CreatePostInput = z.infer<typeof CreatePostInputSchema>;
