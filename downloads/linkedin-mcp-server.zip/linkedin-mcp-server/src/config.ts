/**
 * Environment configuration loading and validation.
 *
 * Secrets (client id/secret) are ALWAYS read from the environment, never
 * hardcoded. We load a .env file if present so local runs are convenient.
 */
import { config as loadDotenv } from "dotenv";
import os from "node:os";
import path from "node:path";
import {
  DEFAULT_LINKEDIN_VERSION,
  DEFAULT_SCOPES,
} from "./constants.js";

loadDotenv();

export interface AppConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  scopes: string[];
  linkedinVersion: string;
  /** Directory where tokens and the post cache are stored. */
  dataDir: string;
  /** Optional explicit author URN override (e.g. "urn:li:person:abc"). */
  authorUrnOverride?: string;
}

function defaultDataDir(): string {
  return process.env.LINKEDIN_DATA_DIR
    ? path.resolve(process.env.LINKEDIN_DATA_DIR)
    : path.join(os.homedir(), ".linkedin-mcp");
}

/**
 * Build configuration needed to run the OAuth flow (auth script).
 * Throws a clear error if required secrets are missing.
 */
export function loadAuthConfig(): AppConfig {
  const clientId = process.env.LINKEDIN_CLIENT_ID?.trim();
  const clientSecret = process.env.LINKEDIN_CLIENT_SECRET?.trim();
  const redirectUri =
    process.env.LINKEDIN_REDIRECT_URI?.trim() ||
    "http://localhost:53682/callback";

  const missing: string[] = [];
  if (!clientId) missing.push("LINKEDIN_CLIENT_ID");
  if (!clientSecret) missing.push("LINKEDIN_CLIENT_SECRET");
  if (missing.length > 0) {
    throw new Error(
      `Missing required environment variable(s): ${missing.join(", ")}. ` +
        `Copy .env.example to .env and fill in your LinkedIn app credentials.`
    );
  }

  const scopes = process.env.LINKEDIN_SCOPES?.trim()
    ? process.env.LINKEDIN_SCOPES.trim().split(/[\s,]+/).filter(Boolean)
    : DEFAULT_SCOPES;

  return {
    clientId: clientId!,
    clientSecret: clientSecret!,
    redirectUri,
    scopes,
    linkedinVersion:
      process.env.LINKEDIN_VERSION?.trim() || DEFAULT_LINKEDIN_VERSION,
    dataDir: defaultDataDir(),
    authorUrnOverride: process.env.LINKEDIN_AUTHOR_URN?.trim() || undefined,
  };
}

/**
 * Build configuration needed to run the MCP server. Same as auth config but
 * the server can still start if the client secret is absent only when a valid
 * (non-refreshable) token already exists; to keep things simple and correct we
 * require the same vars, because refresh needs the secret.
 */
export function loadServerConfig(): AppConfig {
  return loadAuthConfig();
}
