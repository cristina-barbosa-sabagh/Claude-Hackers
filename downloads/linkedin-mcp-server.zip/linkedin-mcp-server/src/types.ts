/**
 * Shared TypeScript types for the LinkedIn MCP server.
 */

/** Persisted OAuth token bundle. */
export interface StoredTokens {
  access_token: string;
  /** Optional: LinkedIn only issues refresh tokens to approved partners. */
  refresh_token?: string;
  /** Absolute expiry of the access token, epoch milliseconds. */
  expires_at: number;
  /** Absolute expiry of the refresh token if present, epoch milliseconds. */
  refresh_token_expires_at?: number;
  /** Scopes the token was granted, space-separated as returned by LinkedIn. */
  scope?: string;
  /** Person URN cached at auth time when resolvable (e.g. "urn:li:person:abc"). */
  author_urn?: string;
}

/** Raw token response from LinkedIn's token endpoint. */
export interface LinkedInTokenResponse {
  access_token: string;
  expires_in: number;
  refresh_token?: string;
  refresh_token_expires_in?: number;
  scope?: string;
  token_type?: string;
}

/** A single changelog event (subset of fields we rely on). */
export interface ChangelogEvent {
  id: number;
  capturedAt: number;
  processedAt: number;
  method: string;
  resourceName: string;
  resourceId: string;
  resourceUri?: string;
  owner?: string;
  actor?: string;
  activity?: Record<string, unknown>;
  processedActivity?: Record<string, unknown>;
}

/** A normalized post stored in the local cache. */
export interface CachedPost {
  /** Stable resource id of the post. */
  resourceId: string;
  resourceName: string;
  /** Extracted post text (commentary). */
  text: string;
  /** Epoch ms when the post was captured by the changelog. */
  capturedAt: number;
  /** Epoch ms when LinkedIn processed the event. */
  processedAt: number;
  /** Author URN if available. */
  author?: string;
}

/** On-disk cache shape. */
export interface PostCacheFile {
  /** Highest processedAt we have synced, used as the next startTime. */
  lastProcessedAt: number;
  /** Map of resourceId -> post, deduplicated. */
  posts: Record<string, CachedPost>;
  /** ISO timestamp of the last successful sync. */
  lastSyncedAt?: string;
}
