#!/usr/bin/env node
/**
 * LinkedIn MCP server — entry point (stdio transport).
 *
 * Exposes exactly two user-facing tools:
 *   - linkedin_read_my_posts   (read your own activity via Member Changelog API)
 *   - linkedin_create_post     (publish to your feed; preview unless confirm=true)
 *
 * Run after building: `node dist/index.js`. Authenticate first with `npm run auth`.
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { SERVER_NAME, SERVER_VERSION } from "./constants.js";
import { loadServerConfig } from "./config.js";
import { registerReadMyPosts } from "./tools/readPosts.js";
import { registerCreatePost } from "./tools/createPost.js";

async function main(): Promise<void> {
  // Fail fast with a clear message if credentials are missing.
  let config;
  try {
    config = loadServerConfig();
  } catch (err) {
    console.error(
      `[${SERVER_NAME}] Configuration error: ${
        err instanceof Error ? err.message : String(err)
      }`
    );
    process.exit(1);
  }

  const server = new McpServer({
    name: SERVER_NAME,
    version: SERVER_VERSION,
  });

  registerReadMyPosts(server, config);
  registerCreatePost(server, config);

  const transport = new StdioServerTransport();
  await server.connect(transport);

  // IMPORTANT: never write to stdout — stdio transport uses it for protocol
  // messages. Diagnostics go to stderr only.
  console.error(`[${SERVER_NAME}] v${SERVER_VERSION} running on stdio.`);
}

main().catch((err) => {
  console.error(
    `[${SERVER_NAME}] Fatal error:`,
    err instanceof Error ? err.message : String(err)
  );
  process.exit(1);
});
