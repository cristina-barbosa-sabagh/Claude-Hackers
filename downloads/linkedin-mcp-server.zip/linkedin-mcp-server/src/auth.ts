#!/usr/bin/env node
/**
 * Standalone 3-legged OAuth script: `npm run auth`.
 *
 * Flow:
 *   1. Spin up a tiny localhost HTTP server on the redirect URI's port.
 *   2. Open the browser to LinkedIn's authorization page (with a CSRF state).
 *   3. Receive the ?code=... callback, exchange it for tokens.
 *   4. Resolve and cache the member's person URN when possible.
 *   5. Persist tokens locally (0600). Refresh later is automatic when LinkedIn
 *      provided a refresh token.
 *
 * No secrets are printed. Client id/secret come from the environment.
 */
import http from "node:http";
import crypto from "node:crypto";
import { URL } from "node:url";
import open from "open";
import {
  LINKEDIN_OAUTH_AUTHORIZE_URL,
} from "./constants.js";
import { loadAuthConfig } from "./config.js";
import {
  exchangeCodeForTokens,
  loadTokens,
  saveTokens,
  toStoredTokens,
} from "./services/tokens.js";
import { resolveAuthorUrn } from "./services/linkedin.js";

function parsePort(redirectUri: string): number {
  const url = new URL(redirectUri);
  if (url.port) return parseInt(url.port, 10);
  return url.protocol === "https:" ? 443 : 80;
}

async function main(): Promise<void> {
  const config = loadAuthConfig();
  const redirect = new URL(config.redirectUri);
  const port = parsePort(config.redirectUri);
  const callbackPath = redirect.pathname || "/callback";
  const state = crypto.randomBytes(16).toString("hex");

  const authUrl = new URL(LINKEDIN_OAUTH_AUTHORIZE_URL);
  authUrl.searchParams.set("response_type", "code");
  authUrl.searchParams.set("client_id", config.clientId);
  authUrl.searchParams.set("redirect_uri", config.redirectUri);
  authUrl.searchParams.set("state", state);
  authUrl.searchParams.set("scope", config.scopes.join(" "));

  const code: string = await new Promise<string>((resolve, reject) => {
    const server = http.createServer((req, res) => {
      if (!req.url) {
        res.writeHead(400).end("Bad request");
        return;
      }
      const reqUrl = new URL(req.url, `http://localhost:${port}`);
      if (reqUrl.pathname !== callbackPath) {
        res.writeHead(404).end("Not found");
        return;
      }

      const error = reqUrl.searchParams.get("error");
      const errorDescription = reqUrl.searchParams.get("error_description");
      const returnedState = reqUrl.searchParams.get("state");
      const returnedCode = reqUrl.searchParams.get("code");

      if (error) {
        res
          .writeHead(400, { "Content-Type": "text/html" })
          .end(htmlPage("Authorization failed", errorDescription || error));
        server.close();
        reject(new Error(`Authorization failed: ${error} ${errorDescription ?? ""}`));
        return;
      }
      if (returnedState !== state) {
        res
          .writeHead(400, { "Content-Type": "text/html" })
          .end(htmlPage("Security error", "State mismatch (possible CSRF). Aborting."));
        server.close();
        reject(new Error("OAuth state mismatch; aborting."));
        return;
      }
      if (!returnedCode) {
        res
          .writeHead(400, { "Content-Type": "text/html" })
          .end(htmlPage("Missing code", "No authorization code was returned."));
        server.close();
        reject(new Error("No authorization code returned."));
        return;
      }

      res
        .writeHead(200, { "Content-Type": "text/html" })
        .end(
          htmlPage(
            "All set!",
            "Authorization complete. You can close this tab and return to the terminal."
          )
        );
      server.close();
      resolve(returnedCode);
    });

    server.on("error", reject);
    server.listen(port, () => {
      console.error(`Listening for the OAuth callback on ${config.redirectUri}`);
      console.error("Opening your browser to authorize the app...");
      console.error(
        "If it doesn't open automatically, paste this URL into your browser:\n" +
          authUrl.toString()
      );
      void open(authUrl.toString());
    });
  });

  console.error("Authorization code received. Exchanging for tokens...");
  const raw = await exchangeCodeForTokens(config, code);
  const existing = await loadTokens(config);
  const stored = toStoredTokens(raw, existing ?? undefined);
  await saveTokens(config, stored);

  // Best-effort: resolve and cache the author URN now so posting is instant.
  try {
    const urn = await resolveAuthorUrn(config);
    console.error(`Resolved your person URN: ${urn}`);
  } catch (err) {
    console.error(
      "Note: could not resolve your person URN yet " +
        `(${err instanceof Error ? err.message : String(err)}). ` +
        "Posting will retry resolution, or set LINKEDIN_AUTHOR_URN in .env."
    );
  }

  console.error("");
  console.error("Success. Tokens saved.");
  console.error(
    raw.refresh_token
      ? "A refresh token was issued; access tokens will refresh automatically."
      : "No refresh token was issued (normal for non-partner apps). When the " +
          "access token expires (~60 days), just run `npm run auth` again."
  );
  process.exit(0);
}

function htmlPage(title: string, body: string): string {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
<style>body{font-family:system-ui,sans-serif;max-width:34rem;margin:4rem auto;padding:0 1rem;color:#1d2939}
h1{font-size:1.3rem}p{color:#475467}</style></head>
<body><h1>${title}</h1><p>${body}</p></body></html>`;
}

main().catch((err) => {
  console.error("Auth failed:", err instanceof Error ? err.message : String(err));
  process.exit(1);
});
