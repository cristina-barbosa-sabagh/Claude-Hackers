/**
 * Shared constants for the LinkedIn MCP server.
 *
 * All values here are non-secret. Secrets (client id/secret) come from the
 * environment (.env) and are loaded in config.ts.
 */

export const SERVER_NAME = "linkedin-mcp-server";
export const SERVER_VERSION = "1.0.0";

// --- LinkedIn API hosts ---
export const LINKEDIN_API_BASE = "https://api.linkedin.com";
export const LINKEDIN_OAUTH_AUTHORIZE_URL =
  "https://www.linkedin.com/oauth/v2/authorization";
export const LINKEDIN_OAUTH_TOKEN_URL =
  "https://www.linkedin.com/oauth/v2/accessToken";

// --- Versioned API header ---
// The Changelog API documentation historically pinned an older version, but
// LinkedIn sunsets each version ~1 year after release, so we default to a
// recent, currently-supported version. Override via LINKEDIN_VERSION if needed.
export const DEFAULT_LINKEDIN_VERSION = "202605";

// Required for the rest/v2 protocol.
export const RESTLI_PROTOCOL_VERSION = "2.0.0";

// --- OAuth scopes ---
// Each scope maps to a LinkedIn "Product" you must enable on your developer app:
//   - openid, profile            -> "Sign In with LinkedIn using OpenID Connect"
//                                   (used to resolve your own person URN via /v2/userinfo)
//   - w_member_social            -> "Share on LinkedIn" (publish posts)
//   - r_dma_portability_member   -> "Member Data Portability API (Member)"
//                                   (read your own activity via the Changelog API)
//
// NOTE: LinkedIn's OAuth tool sometimes labels the DMA member scope as
// `r_dma_portability_self_serve`. Both refer to the same self-serve member
// product; use whichever your provisioned product exposes. This is overridable
// via LINKEDIN_SCOPES in .env.
export const DEFAULT_SCOPES = [
  "openid",
  "profile",
  "w_member_social",
  "r_dma_portability_member",
];

// --- Changelog tuning ---
// The Changelog API only retains the last 28 days of events.
export const CHANGELOG_RETENTION_DAYS = 28;
// LinkedIn recommends count<=50; 50 maximizes events per request for a local sync.
export const CHANGELOG_MAX_COUNT = 50;

// resourceName values in the changelog that represent member-authored posts/shares.
export const POST_RESOURCE_NAMES = [
  "ugcPosts",
  "posts",
  "shares",
  "originalArticles",
];

// --- Response sizing ---
export const CHARACTER_LIMIT = 25000;

// --- HTTP ---
export const REQUEST_TIMEOUT_MS = 30000;
