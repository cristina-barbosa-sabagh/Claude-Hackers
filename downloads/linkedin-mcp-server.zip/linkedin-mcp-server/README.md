# linkedin-mcp-server

Conector **MCP** (Model Context Protocol) para LinkedIn, en TypeScript y transporte **stdio**, pensado para correr local con **Claude Desktop**.

Hace exactamente dos cosas, por las vías **oficiales y legales** de LinkedIn (sin scraping ni cookies):

1. **Leer tu propia actividad** — tus posts, para poder analizar tu tono y estilo. Usa la **Member Data Portability API / Member Changelog** (scope `r_dma_portability_member`). Como el changelog solo conserva los últimos **28 días**, el server mantiene una **cache local** y va acumulando tu historial con cada sincronización.
2. **Publicar posts en tu feed** — con el scope `w_member_social` (producto **Share on LinkedIn**). La herramienta de publicar tiene una **compuerta de confirmación**: por defecto solo devuelve un *preview* y **no publica**; publica únicamente si se la llama con `confirm=true`.

> **Importante para compartir:** este proyecto no incluye credenciales. Si querés que otra persona lo use, **cada quien necesita su propia app de LinkedIn Developer** y sus propias credenciales (client id/secret). Las credenciales nunca van en el código: van en un `.env` local.

---

## Las dos herramientas (tools)

| Tool | Qué hace | Anotaciones |
|------|----------|-------------|
| `linkedin_read_my_posts` | Sincroniza el changelog a la cache local y devuelve tus posts (texto + fecha). | `readOnly` |
| `linkedin_create_post` | Publica un post de texto en tu feed. `confirm=false` → solo preview; `confirm=true` → publica. | `destructive` |

`linkedin_create_post` acepta: `text` (1–3000 chars), `visibility` (`PUBLIC` o `CONNECTIONS`), `confirm` (default `false`).

---

## Requisitos

- **Node.js ≥ 18** (probado con Node 22). Usa `fetch` nativo, sin dependencias HTTP extra.
- Una **app de LinkedIn Developer** con los productos/scopes de abajo.
- **Claude Desktop** (o cualquier cliente MCP con transporte stdio).

---

## 1) Configurar tu app de LinkedIn

Entrá a <https://www.linkedin.com/developers/apps> y creá (o usá) una app. En la pestaña **Products** habilitá:

| Producto a habilitar | Scope que otorga | Para qué |
|----------------------|------------------|----------|
| **Member Data Portability API (Member)** | `r_dma_portability_member`* | Leer tu propia actividad (Changelog) |
| **Share on LinkedIn** | `w_member_social` | Publicar posts en tu feed |
| **Sign In with LinkedIn using OpenID Connect** | `openid`, `profile` | Resolver tu *person URN* (necesario para publicar) |

\* En la herramienta OAuth de LinkedIn este scope a veces aparece como **`r_dma_portability_self_serve`**. Son el mismo producto self-serve para miembros; usá el nombre que te muestre tu app y, si hace falta, ajustalo con `LINKEDIN_SCOPES` en el `.env`.

> **Member Data Portability** solo está disponible para miembros de LinkedIn ubicados en el **Espacio Económico Europeo (EEA) y Suiza**. Si no estás en esa región, la parte de *publicar* funciona igual, pero la de *leer tu actividad* puede no estar disponible para tu cuenta. Es una restricción de LinkedIn, no del conector.

> El producto **Member Data Portability (Member)** exige crear la app usando la *Company Page* por defecto que LinkedIn provee para ese fin; seguí las indicaciones del portal al solicitar el acceso.

En la pestaña **Auth**:

- Copiá tu **Client ID** y **Client Secret**.
- En **Authorized redirect URLs for your app** agregá exactamente:
  `http://localhost:53682/callback`
  (o el que pongas en `LINKEDIN_REDIRECT_URI`; el puerto debe estar libre).

---

## 2) Configurar el proyecto

```bash
# en la carpeta del proyecto
cp .env.example .env
# editá .env y completá al menos:
#   LINKEDIN_CLIENT_ID, LINKEDIN_CLIENT_SECRET, LINKEDIN_REDIRECT_URI
npm install
npm run build
```

Variables de `.env` (las opcionales tienen default sensato):

| Variable | Obligatoria | Default | Descripción |
|----------|:-----------:|---------|-------------|
| `LINKEDIN_CLIENT_ID` | ✅ | — | Client ID de tu app |
| `LINKEDIN_CLIENT_SECRET` | ✅ | — | Client Secret de tu app |
| `LINKEDIN_REDIRECT_URI` | ✅ | `http://localhost:53682/callback` | Debe coincidir con el registrado en LinkedIn |
| `LINKEDIN_SCOPES` | — | `openid profile w_member_social r_dma_portability_member` | Scopes a pedir |
| `LINKEDIN_VERSION` | — | `202605` | Header `LinkedIn-Version` (formato YYYYMM; LinkedIn retira versiones ~1 año después de su release) |
| `LINKEDIN_AUTHOR_URN` | — | (auto) | Forzar tu `urn:li:person:...` si la resolución automática falla |
| `LINKEDIN_DATA_DIR` | — | `~/.linkedin-mcp` | Dónde se guardan tokens y cache |

Los **tokens** y la **cache** se guardan en `LINKEDIN_DATA_DIR` con permisos `0600`. Nunca se imprimen ni se commitean.

---

## 3) Autenticarte (OAuth 3-legged)

```bash
npm run auth
```

Esto:

1. Levanta un servidor local en el `redirect_uri`.
2. Abre el navegador en la pantalla de consentimiento de LinkedIn.
3. Recibe el `code` en `localhost`, lo intercambia por tokens y los guarda localmente.
4. Resuelve y cachea tu *person URN* para que publicar sea inmediato.

**Sobre el refresh:** LinkedIn solo entrega *refresh tokens* a apps de partners aprobados. Si tu app recibe uno, el conector **renueva el access token automáticamente**. Si no (lo más común), el access token dura ~60 días y, al expirar, basta con volver a correr `npm run auth`. El conector te avisa con un mensaje claro cuando hay que re-autenticarse.

---

## 4) Conectarlo a Claude Desktop

Editá el archivo de configuración de Claude Desktop:

- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

Agregá el server (usá rutas **absolutas**):

```json
{
  "mcpServers": {
    "linkedin": {
      "command": "node",
      "args": ["/ruta/absoluta/a/linkedin-mcp-server/dist/index.js"],
      "env": {
        "LINKEDIN_CLIENT_ID": "tu_client_id",
        "LINKEDIN_CLIENT_SECRET": "tu_client_secret",
        "LINKEDIN_REDIRECT_URI": "http://localhost:53682/callback"
      }
    }
  }
}
```

> Podés poner las variables en el bloque `env` de arriba **o** dejarlas en el `.env` del proyecto (el server lo carga solo). Para `npm run auth` conviene tenerlas en el `.env`.

Reiniciá Claude Desktop. Deberías ver las tools `linkedin_read_my_posts` y `linkedin_create_post`.

---

## Flujo recomendado de publicación (seguro)

1. Pedile a Claude que prepare el post → llama a `linkedin_create_post` con `confirm=false` → **muestra un preview**, no publica nada.
2. Revisás el texto.
3. Solo si aprobás, Claude vuelve a llamar con `confirm=true` → **publica**.

La publicación es prácticamente irreversible desde la API (habría que borrar el post en la app de LinkedIn), por eso la confirmación explícita es obligatoria.

---

## Probar sin Claude (opcional)

```bash
npx @modelcontextprotocol/inspector node dist/index.js
```

---

## Estructura del proyecto

```
linkedin-mcp-server/
├── package.json
├── tsconfig.json
├── .env.example
├── .gitignore
├── README.md
└── src/
    ├── index.ts            # entry point del MCP server (stdio)
    ├── auth.ts             # script `npm run auth` (OAuth 3-legged)
    ├── config.ts           # carga/validación de .env
    ├── constants.ts        # URLs, scopes, headers, límites
    ├── types.ts            # tipos compartidos
    ├── schemas/index.ts    # schemas Zod de las tools
    ├── services/
    │   ├── tokens.ts       # almacenamiento + refresh de tokens
    │   ├── linkedin.ts     # cliente de la API + manejo de errores
    │   └── cache.ts        # cache local + sync del changelog
    └── tools/
        ├── readPosts.ts    # tool de lectura
        └── createPost.ts   # tool de publicación (con gate confirm)
```

---

## Solución de problemas

| Síntoma | Causa probable / solución |
|---------|---------------------------|
| `403 Forbidden` al leer o publicar | Falta habilitar el producto/scope correspondiente en tu app. |
| `401 Unauthorized` | Token vencido o inválido → `npm run auth` de nuevo. |
| `No stored LinkedIn tokens were found` | Todavía no te autenticaste → `npm run auth`. |
| Lees 0 posts al inicio | El changelog solo archiva actividad **posterior** a tu consentimiento; publicá o esperá y volvé a sincronizar. Además, requiere cuenta en EEA/Suiza. |
| No resuelve tu *person URN* | Habilitá "Sign In with LinkedIn using OpenID Connect", o seteá `LINKEDIN_AUTHOR_URN` en el `.env`. |
| `400 Bad Request` al publicar | Revisá `LINKEDIN_VERSION`; LinkedIn pudo haber cambiado la versión soportada. |
| `426 NONEXISTENT_VERSION` | La `LINKEDIN_VERSION` quedó vieja y LinkedIn la retiró. Subila a una versión reciente (YYYYMM), por ej. la del mes actual o el anterior. |

---

## Notas legales y de privacidad

- Usa exclusivamente APIs oficiales de LinkedIn. **No** hace scraping ni usa cookies de sesión.
- Solo accede a **tu propia** información (la del miembro autenticado).
- Tus credenciales y tokens quedan **solo en tu máquina**.
- El uso queda sujeto a los Términos de las APIs de LinkedIn (incluidos los *DMA Portability API Terms*).

## Licencia

MIT
